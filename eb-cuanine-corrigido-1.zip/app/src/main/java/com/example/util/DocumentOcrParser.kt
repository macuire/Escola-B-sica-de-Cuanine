package com.example.util

import java.util.Calendar
import java.util.Locale

data class ParsedDocument(
    val name: String? = null,
    val birthDate: String? = null, // AAAA-MM-DD
    val docNumber: String? = null,
    val phone: String? = null
)

/**
 * Extrai campos prováveis do texto lido por OCR numa fotografia de BI / cédula.
 * Só devolve o que encontrar; nunca inventa valores. O utilizador deve sempre rever.
 */
object DocumentOcrParser {

    private val nameLabel = Regex("^nome(\\s+completo)?\\s*[:.\\-]?\\s*(.*)$", RegexOption.IGNORE_CASE)
    private val plausibleName = Regex("^[\\p{L}][\\p{L}'.\\- ]{4,}$")
    private val dateRegex = Regex(
        "(\\d{1,2})[/.\\- ](\\d{1,2})[/.\\- ](\\d{4})|(\\d{4})[/.\\-](\\d{1,2})[/.\\-](\\d{1,2})"
    )
    private val biRegex = Regex("\\b\\d{12}[A-Za-z]\\b")
    private val phoneRegex = Regex("(?:\\+?258[\\s-]?)?(8[2-7]\\d{7})")

    fun parse(text: String): ParsedDocument {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        return ParsedDocument(
            name = findName(lines),
            birthDate = findBirthDate(lines),
            docNumber = biRegex.find(text)?.value?.uppercase(Locale.ROOT),
            phone = phoneRegex.find(text)?.let { formatPhone(it.groupValues[1]) }
        )
    }

    private fun isPlausibleName(candidate: String): Boolean =
        candidate.contains(' ') && plausibleName.matches(candidate)

    private fun findName(lines: List<String>): String? {
        for ((i, line) in lines.withIndex()) {
            val m = nameLabel.matchEntire(line) ?: continue
            val rest = m.groupValues[2].trim()
            val candidate = if (rest.length >= 5) rest else lines.getOrNull(i + 1)?.trim().orEmpty()
            if (isPlausibleName(candidate)) return candidate
        }
        return null
    }

    private fun findBirthDate(lines: List<String>): String? {
        for ((i, line) in lines.withIndex()) {
            if (!line.contains("nasc", ignoreCase = true)) continue
            val date = toIsoDate(line) ?: lines.getOrNull(i + 1)?.let { toIsoDate(it) }
            if (date != null) return date
        }
        return null
    }

    private fun toIsoDate(text: String): String? {
        val m = dateRegex.find(text) ?: return null
        val g = m.groupValues
        val day: Int
        val month: Int
        val year: Int
        if (g[3].isNotEmpty()) {
            day = g[1].toInt(); month = g[2].toInt(); year = g[3].toInt()
        } else {
            year = g[4].toInt(); month = g[5].toInt(); day = g[6].toInt()
        }
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        if (month !in 1..12 || day !in 1..31 || year !in 1990..currentYear) return null
        return String.format(Locale.ROOT, "%04d-%02d-%02d", year, month, day)
    }

    private fun formatPhone(nine: String): String =
        "+258 " + nine.take(2) + " " + nine.drop(2)
}
