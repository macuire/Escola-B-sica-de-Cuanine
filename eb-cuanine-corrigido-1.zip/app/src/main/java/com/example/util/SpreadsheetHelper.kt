package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.model.Student
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.zip.ZipInputStream

data class ParsedSheet(
    val fileName: String,
    val headers: List<String>,
    val rows: List<List<String>>
)

data class ColumnMapping(
    val nameColIdx: Int = -1,
    val numberColIdx: Int = -1,
    val genderColIdx: Int = -1,
    val birthColIdx: Int = -1,
    val classColIdx: Int = -1,
    val sectionColIdx: Int = -1,
    val guardianColIdx: Int = -1,
    val phoneColIdx: Int = -1,
    val docTypeColIdx: Int = -1,
    val docNumColIdx: Int = -1
)

object SpreadsheetHelper {

    /**
     * Lê um arquivo de planilha CSV ou XLSX do armazenamento ou Uri.
     */
    fun parseSpreadsheet(context: Context, uri: Uri, fileName: String): ParsedSheet {
        return if (fileName.endsWith(".xlsx", ignoreCase = true)) {
            parseXlsx(context, uri, fileName)
        } else {
            parseCsv(context, uri, fileName)
        }
    }

    /**
     * Parser nativo para CSV com detecção de delimitador (, ou ;)
     */
    fun parseCsv(context: Context, uri: Uri, fileName: String): ParsedSheet {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return ParsedSheet(fileName, emptyList(), emptyList())
        val reader = BufferedReader(InputStreamReader(inputStream))
        val rawLines = mutableListOf<String>()
        reader.useLines { lines ->
            lines.forEach { line ->
                if (line.isNotBlank()) rawLines.add(line.trim())
            }
        }

        if (rawLines.isEmpty()) return ParsedSheet(fileName, emptyList(), emptyList())

        // Detectar delimitador baseado na primeira linha
        val firstLine = rawLines.first()
        val delimiter = if (firstLine.count { it == ';' } > firstLine.count { it == ',' }) ';' else ','

        val allRows = rawLines.map { line ->
            parseCsvLine(line, delimiter)
        }

        val headers = allRows.firstOrNull() ?: emptyList()
        val dataRows = if (allRows.size > 1) allRows.drop(1) else emptyList()

        return ParsedSheet(fileName, headers, dataRows)
    }

    private fun parseCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val cur = StringBuilder()
        var inQuotes = false

        for (c in line) {
            when {
                c == '"' -> inQuotes = !inQuotes
                c == delimiter && !inQuotes -> {
                    result.add(cur.toString().trim())
                    cur.clear()
                }
                else -> cur.append(c)
            }
        }
        result.add(cur.toString().trim())
        return result
    }

    /**
     * Parser nativo para XLSX sem dependências pesadas externas.
     * Lê xl/sharedStrings.xml e xl/worksheets/sheet1.xml usando ZipInputStream + XmlPullParser.
     */
    fun parseXlsx(context: Context, uri: Uri, fileName: String): ParsedSheet {
        val sharedStrings = mutableListOf<String>()
        val sheetRows = mutableListOf<List<String>>()

        // Passo 1: extrair sharedStrings.xml
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            ZipInputStream(inputStream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name.equals("xl/sharedStrings.xml", ignoreCase = true)) {
                        readSharedStrings(zis, sharedStrings)
                        break
                    }
                    entry = zis.nextEntry
                }
            }
        }

        // Passo 2: extrair sheet1.xml
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            ZipInputStream(inputStream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name.equals("xl/worksheets/sheet1.xml", ignoreCase = true)) {
                        readSheetData(zis, sharedStrings, sheetRows)
                        break
                    }
                    entry = zis.nextEntry
                }
            }
        }

        val headers = sheetRows.firstOrNull() ?: emptyList()
        val dataRows = if (sheetRows.size > 1) sheetRows.drop(1) else emptyList()

        return ParsedSheet(fileName, headers, dataRows)
    }

    private fun readSharedStrings(inputStream: InputStream, target: MutableList<String>) {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(inputStream, "UTF-8")

        var eventType = parser.eventType
        val textBuilder = StringBuilder()
        var insideT = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (parser.name == "t") {
                        insideT = true
                        textBuilder.clear()
                    }
                }
                XmlPullParser.TEXT -> {
                    if (insideT) {
                        textBuilder.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "t") {
                        insideT = false
                        target.add(textBuilder.toString())
                    }
                }
            }
            eventType = parser.next()
        }
    }

    private fun readSheetData(
        inputStream: InputStream,
        sharedStrings: List<String>,
        targetRows: MutableList<List<String>>
    ) {
        val factory = XmlPullParserFactory.newInstance()
        val parser = factory.newPullParser()
        parser.setInput(inputStream, "UTF-8")

        var eventType = parser.eventType
        var currentRow = mutableListOf<String>()
        var currentCellType: String? = null
        var isVTag = false
        var cellVal = StringBuilder()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "row" -> currentRow = mutableListOf()
                        "c" -> {
                            currentCellType = parser.getAttributeValue(null, "t")
                        }
                        "v" -> {
                            isVTag = true
                            cellVal.clear()
                        }
                    }
                }
                XmlPullParser.TEXT -> {
                    if (isVTag) {
                        cellVal.append(parser.text)
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "v" -> {
                            isVTag = false
                            val raw = cellVal.toString().trim()
                            val parsedValue = if (currentCellType == "s") {
                                val idx = raw.toIntOrNull()
                                if (idx != null && idx < sharedStrings.size) sharedStrings[idx] else raw
                            } else {
                                raw
                            }
                            currentRow.add(parsedValue)
                        }
                        "row" -> {
                            if (currentRow.isNotEmpty()) {
                                targetRows.add(currentRow)
                            }
                        }
                    }
                }
            }
            eventType = parser.next()
        }
    }

    /**
     * Aplica o mapeamento visual de colunas para converter as linhas em entidades de Aluno.
     */
    fun convertRowsToStudents(
        rows: List<List<String>>,
        mapping: ColumnMapping,
        defaultGradeClass: Int = 1,
        defaultSection: String = "A"
    ): List<Student> {
        val students = mutableListOf<Student>()
        val now = System.currentTimeMillis()

        rows.forEachIndexed { idx, row ->
            val name = if (mapping.nameColIdx in row.indices) row[mapping.nameColIdx] else ""
            if (name.isNotBlank()) {
                val num = if (mapping.numberColIdx in row.indices) row[mapping.numberColIdx] else "EBC-2026-${String.format("%03d", 100 + idx)}"
                val gen = if (mapping.genderColIdx in row.indices) {
                    val g = row[mapping.genderColIdx].trim().uppercase()
                    if (g.startsWith("F") || g.contains("FEM")) "F" else "M"
                } else "M"
                val birth = if (mapping.birthColIdx in row.indices) row[mapping.birthColIdx] else "2015-01-01"
                val gClass = if (mapping.classColIdx in row.indices) {
                    row[mapping.classColIdx].filter { it.isDigit() }.toIntOrNull() ?: defaultGradeClass
                } else defaultGradeClass

                val sec = if (mapping.sectionColIdx in row.indices) {
                    row[mapping.sectionColIdx].take(1).uppercase().ifBlank { defaultSection }
                } else defaultSection

                val guardian = if (mapping.guardianColIdx in row.indices) row[mapping.guardianColIdx] else "Encarregado"
                val phone = if (mapping.phoneColIdx in row.indices) row[mapping.phoneColIdx] else "+258 84 000 0000"
                val docType = if (mapping.docTypeColIdx in row.indices) row[mapping.docTypeColIdx] else "BI"
                val docNum = if (mapping.docNumColIdx in row.indices) row[mapping.docNumColIdx] else ""

                val cycle = SneCalculator.getCycleForGrade(gClass)

                students.add(
                    Student(
                        studentNumber = num,
                        fullName = name,
                        birthDate = birth,
                        gender = gen,
                        guardianName = guardian,
                        guardianPhone = phone,
                        cycle = cycle,
                        gradeClass = gClass,
                        section = sec,
                        docType = docType,
                        docNumber = docNum,
                        accessPin = "1234",
                        createdAt = now
                    )
                )
            }
        }
        return students
    }
}
