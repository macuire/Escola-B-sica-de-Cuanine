package com.example.util

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object CaptureFiles {
    /** Cria um endereço seguro (FileProvider) para a câmara do sistema gravar uma fotografia. */
    fun newCaptureUri(context: Context, fileName: String): Uri {
        val dir = File(context.cacheDir, "capturas").apply { mkdirs() }
        val file = File(dir, fileName)
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }
}
