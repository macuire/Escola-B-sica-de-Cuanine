package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExporter {

    private fun getExportDir(context: Context): File {
        val dir = File(context.filesDir, "exports")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun shareFile(context: Context, file: File, mimeType: String = "application/pdf") {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Partilhar documento: ${file.name}")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * Emite a Pauta Oficial de Avaliação em PDF (Compatível com normas do MEDH Moçambique).
     */
    fun exportPautaPdf(
        context: Context,
        classroom: Classroom,
        subject: Subject,
        term: Int,
        students: List<Student>,
        gradesMap: Map<Long, GradeRecord>
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create() // A4 standard (595 x 842 pt)
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 11f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val subPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 8.5f
            textAlign = Paint.Align.CENTER
        }
        val headerBoxPaint = Paint().apply {
            color = Color.rgb(10, 37, 64) // Cuanine Navy
            style = Paint.Style.FILL
        }
        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 8.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 8f
        }
        val borderPaint = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val passPaint = Paint().apply {
            color = Color.rgb(22, 163, 74)
            textSize = 8f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val failPaint = Paint().apply {
            color = Color.rgb(220, 38, 38)
            textSize = 8f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var y = 35f
        canvas.drawText("REPÚBLICA DE MOÇAMBIQUE", 297f, y, titlePaint)
        y += 12f
        canvas.drawText("MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO", 297f, y, subPaint)
        y += 10f
        canvas.drawText("DIRECÇÃO DISTRITAL DE EDUCAÇÃO, JUVENTUDE E TECNOLOGIA DA MANHIÇA", 297f, y, subPaint)
        y += 12f
        titlePaint.textSize = 12f
        canvas.drawText("ESCOLA BÁSICA DE CUANINE", 297f, y, titlePaint)
        y += 15f

        // Linha divisória
        borderPaint.color = Color.rgb(10, 37, 64)
        borderPaint.strokeWidth = 1.5f
        canvas.drawLine(30f, y, 565f, y, borderPaint)
        y += 16f

        // Identificação da Pauta
        val infoPaint = Paint().apply {
            color = Color.BLACK
            textSize = 8.5f
            isFakeBoldText = true
        }
        canvas.drawText("PAUTA OFICIAL DE AVALIAÇÃO - $term.º TRIMESTRE / 2026", 30f, y, infoPaint)
        y += 12f
        val cycleName = SneCalculator.getCycleTitle(classroom.cycle)
        infoPaint.isFakeBoldText = false
        canvas.drawText("Turma: ${classroom.grade}.ª Classe '${classroom.section}'  |  Ciclo: $cycleName  |  Turno: ${classroom.shift}", 30f, y, infoPaint)
        y += 11f
        canvas.drawText("Disciplina: ${subject.name}  |  Docente: ${classroom.classTeacher}", 30f, y, infoPaint)
        y += 16f

        // Cabeçalho da Tabela
        val tableTop = y
        val tableBottom = 750f
        val colN = 30f
        val colName = 55f
        val colAcs1 = 260f
        val colAcs2 = 305f
        val colAt = 350f
        val colMedia = 395f
        val colResult = 450f
        val colObs = 515f
        val tableRight = 565f

        val rowHeight = 18f
        canvas.drawRect(colN, tableTop, tableRight, tableTop + rowHeight, headerBoxPaint)

        canvas.drawText("N.º", colN + 12f, tableTop + 12f, headerTextPaint)
        canvas.drawText("Nome do Aluno", colName + 95f, tableTop + 12f, headerTextPaint)
        canvas.drawText("ACS 1", colAcs1 + 20f, tableTop + 12f, headerTextPaint)
        canvas.drawText("ACS 2", colAcs2 + 20f, tableTop + 12f, headerTextPaint)
        canvas.drawText("AT", colAt + 20f, tableTop + 12f, headerTextPaint)
        canvas.drawText("MÉDIA", colMedia + 25f, tableTop + 12f, headerTextPaint)
        canvas.drawText("RESULTADO", colResult + 30f, tableTop + 12f, headerTextPaint)

        borderPaint.color = Color.LTGRAY
        borderPaint.strokeWidth = 0.5f

        var curY = tableTop + rowHeight
        students.forEachIndexed { index, student ->
            if (curY + rowHeight < tableBottom) {
                val grade = gradesMap[student.id]

                // Linha de fundo alternada
                if (index % 2 == 1) {
                    val zebraPaint = Paint().apply {
                        color = Color.rgb(245, 247, 250)
                        style = Paint.Style.FILL
                    }
                    canvas.drawRect(colN, curY, tableRight, curY + rowHeight, zebraPaint)
                }

                // Grid borders
                canvas.drawRect(colN, curY, tableRight, curY + rowHeight, borderPaint)

                // Valores
                val textY = curY + 12f
                textPaint.textAlign = Paint.Align.CENTER
                canvas.drawText("${index + 1}", colN + 12f, textY, textPaint)

                textPaint.textAlign = Paint.Align.LEFT
                val displayFullName = if (student.fullName.length > 32) student.fullName.substring(0, 30) + ".." else student.fullName
                canvas.drawText(displayFullName, colName + 4f, textY, textPaint)

                textPaint.textAlign = Paint.Align.CENTER
                if (classroom.cycle == 1) {
                    // 1º Ciclo Avaliação Descritiva
                    val mention = grade?.qualitative ?: SneCalculator.getQualitativeMention(grade?.termAverage)
                    canvas.drawText(mention, colAcs1 + 70f, textY, textPaint)
                    val isPass = (grade?.termAverage ?: 10.0) >= 10.0
                    val resPaint = if (isPass) passPaint else failPaint
                    canvas.drawText(if (isPass) "APTO" else "N/APTO", colResult + 30f, textY, resPaint)
                } else {
                    canvas.drawText(grade?.acs1?.let { String.format(Locale.US, "%.1f", it) } ?: "-", colAcs1 + 20f, textY, textPaint)
                    canvas.drawText(grade?.acs2?.let { String.format(Locale.US, "%.1f", it) } ?: "-", colAcs2 + 20f, textY, textPaint)
                    canvas.drawText(grade?.at?.let { String.format(Locale.US, "%.1f", it) } ?: "-", colAt + 20f, textY, textPaint)
                    
                    val avg = grade?.termAverage
                    val avgStr = avg?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
                    canvas.drawText(avgStr, colMedia + 25f, textY, textPaint)

                    val isPass = avg != null && avg >= 10.0
                    val resPaint = if (isPass) passPaint else failPaint
                    val resText = if (avg == null) "PEND" else if (isPass) "TRANSITA" else "N/TRANSITA"
                    canvas.drawText(resText, colResult + 30f, textY, resPaint)
                }

                curY += rowHeight
            }
        }

        // Rodapé com data e assinaturas
        val footerY = 780f
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val dateStr = "Emitido em Cuanine, Manhiça aos ${sdf.format(Date())}"
        subPaint.textAlign = Paint.Align.LEFT
        canvas.drawText(dateStr, 30f, footerY, subPaint)

        val signPaint = Paint().apply {
            color = Color.BLACK
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawLine(100f, footerY + 25f, 240f, footerY + 25f, borderPaint)
        canvas.drawText("O Professor da Disciplina", 170f, footerY + 35f, signPaint)

        canvas.drawLine(350f, footerY + 25f, 490f, footerY + 25f, borderPaint)
        canvas.drawText("A Direcção da Escola", 420f, footerY + 35f, signPaint)

        doc.finishPage(page)

        val filename = "Pauta_${classroom.grade}Class_${classroom.section}_${subject.code}_T$term.pdf"
        val outFile = File(getExportDir(context), filename)
        FileOutputStream(outFile).use { fos ->
            doc.writeTo(fos)
        }
        doc.close()
        return outFile
    }

    /**
     * Emite o Boletim Individual de Aproveitamento do Aluno em PDF.
     */
    fun exportBoletimPdf(
        context: Context,
        student: Student,
        subjects: List<Subject>,
        grades: List<GradeRecord>
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val subPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 8.5f
            textAlign = Paint.Align.CENTER
        }
        val headerBoxPaint = Paint().apply {
            color = Color.rgb(10, 37, 64)
            style = Paint.Style.FILL
        }
        val headerTextPaint = Paint().apply {
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 8.5f
        }
        val borderPaint = Paint().apply {
            color = Color.LTGRAY
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }

        var y = 40f
        canvas.drawText("REPÚBLICA DE MOÇAMBIQUE", 297f, y, titlePaint)
        y += 12f
        canvas.drawText("MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO", 297f, y, subPaint)
        y += 10f
        canvas.drawText("ESCOLA BÁSICA DE CUANINE - DISTRITO DA MANHIÇA", 297f, y, subPaint)
        y += 14f
        titlePaint.textSize = 13f
        canvas.drawText("BOLETIM INDIVIDUAL DE APROVEITAMENTO ESCOLAR", 297f, y, titlePaint)
        y += 18f

        // Ficha do Aluno
        val boxPaint = Paint().apply {
            color = Color.rgb(241, 245, 249)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(30f, y, 565f, y + 65f), 6f, 6f, boxPaint)
        canvas.drawRoundRect(RectF(30f, y, 565f, y + 65f), 6f, 6f, borderPaint)

        val infoY = y + 15f
        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 8.5f
            isFakeBoldText = true
        }
        canvas.drawText("Nome do Aluno:", 40f, infoY, boldPaint)
        canvas.drawText(student.fullName, 120f, infoY, textPaint)

        canvas.drawText("N.º Matrícula:", 360f, infoY, boldPaint)
        canvas.drawText(student.studentNumber, 440f, infoY, textPaint)

        canvas.drawText("Classe / Turma:", 40f, infoY + 16f, boldPaint)
        canvas.drawText("${student.gradeClass}.ª Classe '${student.section}' (${SneCalculator.getCycleTitle(student.cycle)})", 120f, infoY + 16f, textPaint)

        canvas.drawText("Ano Lectivo:", 360f, infoY + 16f, boldPaint)
        canvas.drawText("${student.schoolYear}", 440f, infoY + 16f, textPaint)

        canvas.drawText("Encarregado:", 40f, infoY + 32f, boldPaint)
        canvas.drawText("${student.guardianName} (${student.guardianPhone})", 120f, infoY + 32f, textPaint)

        y += 80f

        // Tabela de Disciplinas
        val tableTop = y
        val rowHeight = 22f
        canvas.drawRect(30f, tableTop, 565f, tableTop + rowHeight, headerBoxPaint)
        canvas.drawText("Disciplina", 110f, tableTop + 14f, headerTextPaint)
        canvas.drawText("1.º Trim.", 260f, tableTop + 14f, headerTextPaint)
        canvas.drawText("2.º Trim.", 330f, tableTop + 14f, headerTextPaint)
        canvas.drawText("3.º Trim.", 400f, tableTop + 14f, headerTextPaint)
        canvas.drawText("Média Final", 470f, tableTop + 14f, headerTextPaint)
        canvas.drawText("Resultado", 535f, tableTop + 14f, headerTextPaint)

        var curY = tableTop + rowHeight
        var sumGrades = 0.0
        var countGrades = 0

        subjects.forEachIndexed { idx, sub ->
            val g1 = grades.find { it.subjectId == sub.id && it.term == 1 }
            val g2 = grades.find { it.subjectId == sub.id && it.term == 2 }
            val g3 = grades.find { it.subjectId == sub.id && it.term == 3 }

            if (idx % 2 == 1) {
                val zPaint = Paint().apply { color = Color.rgb(248, 250, 252); style = Paint.Style.FILL }
                canvas.drawRect(30f, curY, 565f, curY + rowHeight, zPaint)
            }
            canvas.drawRect(30f, curY, 565f, curY + rowHeight, borderPaint)

            val ty = curY + 14f
            textPaint.textAlign = Paint.Align.LEFT
            canvas.drawText(sub.name, 38f, ty, textPaint)

            textPaint.textAlign = Paint.Align.CENTER
            val s1 = g1?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val s2 = g2?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            val s3 = g3?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: "-"
            canvas.drawText(s1, 260f, ty, textPaint)
            canvas.drawText(s2, 330f, ty, textPaint)
            canvas.drawText(s3, 400f, ty, textPaint)

            // Média da disciplina
            val validTerms = listOfNotNull(g1?.termAverage, g2?.termAverage, g3?.termAverage)
            if (validTerms.isNotEmpty()) {
                val subAvg = validTerms.average()
                sumGrades += subAvg
                countGrades++
                val pass = subAvg >= 10.0
                val col = if (pass) Color.rgb(22, 163, 74) else Color.rgb(220, 38, 38)
                val statusPaint = Paint().apply {
                    color = col
                    textSize = 8.5f
                    isFakeBoldText = true
                    textAlign = Paint.Align.CENTER
                }
                canvas.drawText(String.format(Locale.US, "%.1f", subAvg), 470f, ty, statusPaint)
                canvas.drawText(if (pass) "Aprov." else "Reprov.", 535f, ty, statusPaint)
            } else {
                canvas.drawText("-", 470f, ty, textPaint)
                canvas.drawText("Pendente", 535f, ty, textPaint)
            }

            curY += rowHeight
        }

        // Resumo Geral
        curY += 15f
        if (countGrades > 0) {
            val generalAvg = sumGrades / countGrades
            val summaryPaint = Paint().apply {
                color = Color.BLACK
                textSize = 10f
                isFakeBoldText = true
            }
            canvas.drawText("MÉDIA GERAL DO ALUNO: ${String.format(Locale.US, "%.2f", generalAvg)} Valores", 35f, curY, summaryPaint)
            val passGlobal = generalAvg >= 10.0
            val resWord = if (passGlobal) "APROVADO(A) COM SUCESSO NO ANO LECTIVO" else "NECESSITA DE RECUPERAÇÃO"
            summaryPaint.color = if (passGlobal) Color.rgb(22, 163, 74) else Color.rgb(220, 38, 38)
            canvas.drawText("SITUAÇÃO FINAL: $resWord", 35f, curY + 16f, summaryPaint)
        }

        // Assinaturas
        val footerY = 760f
        canvas.drawLine(70f, footerY, 230f, footerY, borderPaint)
        canvas.drawText("O Director de Turma", 150f, footerY + 12f, subPaint)

        canvas.drawLine(370f, footerY, 530f, footerY, borderPaint)
        canvas.drawText("O Director da Escola", 450f, footerY + 12f, subPaint)

        doc.finishPage(page)

        val cleanName = student.fullName.replace(" ", "_").take(15)
        val file = File(getExportDir(context), "Boletim_${student.studentNumber}_$cleanName.pdf")
        FileOutputStream(file).use { fos -> doc.writeTo(fos) }
        doc.close()
        return file
    }

    /**
     * Declaração de Matrícula e Frequência Oficial da EB Cuanine.
     */
    fun exportCertificadoMatriculaPdf(
        context: Context,
        student: Student
    ): File {
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val titlePaint = Paint().apply {
            color = Color.BLACK
            textSize = 13f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val subPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 9f
            textAlign = Paint.Align.CENTER
        }
        val bodyPaint = Paint().apply {
            color = Color.BLACK
            textSize = 10.5f
            textAlign = Paint.Align.LEFT
        }

        var y = 70f
        canvas.drawText("REPÚBLICA DE MOÇAMBIQUE", 297f, y, titlePaint)
        y += 14f
        canvas.drawText("MINISTÉRIO DA EDUCAÇÃO E DESENVOLVIMENTO HUMANO", 297f, y, subPaint)
        y += 12f
        canvas.drawText("PROVÍNCIA DE MAPUTO - GOVERNO DO DISTRITO DA MANHIÇA", 297f, y, subPaint)
        y += 12f
        canvas.drawText("SERVIÇO DISTRITAL DE EDUCAÇÃO, JUVENTUDE E TECNOLOGIA", 297f, y, subPaint)
        y += 20f
        titlePaint.textSize = 14f
        canvas.drawText("ESCOLA BÁSICA DE CUANINE", 297f, y, titlePaint)
        y += 35f

        titlePaint.textSize = 16f
        canvas.drawText("DECLARAÇÃO DE MATRÍCULA E FREQUÊNCIA", 297f, y, titlePaint)
        y += 45f

        val text1 = "Para os devidos efeitos legais, declara-se que o(a) aluno(a):"
        canvas.drawText(text1, 50f, y, bodyPaint)
        y += 25f

        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            isFakeBoldText = true
        }
        canvas.drawText(student.fullName.uppercase(Locale.getDefault()), 50f, y, boldPaint)
        y += 22f

        val text2 = "Portador(a) do ${student.docType} n.º ${student.docNumber.ifBlank { "N/D" }}, nascido(a) em ${student.birthDate},"
        canvas.drawText(text2, 50f, y, bodyPaint)
        y += 20f

        val text3 = "filho(a) de ${student.guardianName}, encontra-se regularmente matriculado(a)"
        canvas.drawText(text3, 50f, y, bodyPaint)
        y += 20f

        val text4 = "e a frequentar o ano lectivo de ${student.schoolYear} na ${student.gradeClass}.ª Classe, Turma '${student.section}',"
        canvas.drawText(text4, 50f, y, bodyPaint)
        y += 20f

        val text5 = "integrada no ${SneCalculator.getCycleTitle(student.cycle)} do Sistema Nacional de Educação (SNE)."
        canvas.drawText(text5, 50f, y, bodyPaint)
        y += 35f

        val text6 = "Por ser verdade e para os fins a que convier, mandou-se passar a presente"
        canvas.drawText(text6, 50f, y, bodyPaint)
        y += 20f
        val text7 = "declaração que vai por mim assinada e autenticada com o carimbo a óleo desta escola."
        canvas.drawText(text7, 50f, y, bodyPaint)
        y += 45f

        val sdf = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("pt", "MZ"))
        val dateLoc = "Cuanine (Manhiça), aos ${sdf.format(Date())}"
        val datePaint = Paint().apply {
            color = Color.BLACK
            textSize = 10f
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(dateLoc, 545f, y, datePaint)
        y += 80f

        val signBorder = Paint().apply {
            color = Color.BLACK
            strokeWidth = 1f
        }
        canvas.drawLine(197f, y, 397f, y, signBorder)
        y += 15f
        subPaint.textSize = 10f
        canvas.drawText("A Direcção da Escola Básica de Cuanine", 297f, y, subPaint)

        doc.finishPage(page)

        val clean = student.fullName.replace(" ", "_").take(15)
        val file = File(getExportDir(context), "Declaracao_Matricula_${student.studentNumber}_$clean.pdf")
        FileOutputStream(file).use { fos -> doc.writeTo(fos) }
        doc.close()
        return file
    }
}
