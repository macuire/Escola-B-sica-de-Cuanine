package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AttendanceRecord
import com.example.data.model.Classroom
import com.example.data.model.FormulaConfig
import com.example.data.model.GradeRecord
import com.example.data.model.PautaLock
import com.example.data.model.SchoolNotice
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.data.model.Teacher
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {

    // ================= Alunos =================
    @Query("SELECT * FROM students ORDER BY gradeClass ASC, section ASC, fullName ASC")
    fun getAllStudents(): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE gradeClass = :gradeClass AND section = :section ORDER BY fullName ASC")
    fun getStudentsByClass(gradeClass: Int, section: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE cycle = :cycle ORDER BY gradeClass ASC, section ASC, fullName ASC")
    fun getStudentsByCycle(cycle: Int): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE enrollmentStatus = :status ORDER BY gradeClass ASC, section ASC, fullName ASC")
    fun getStudentsByEnrollmentStatus(status: String): Flow<List<Student>>

    @Query("""
        SELECT * FROM students 
        WHERE fullName LIKE '%' || :query || '%' 
           OR studentNumber LIKE '%' || :query || '%'
           OR docNumber LIKE '%' || :query || '%'
        ORDER BY fullName ASC
    """)
    fun searchStudents(query: String): Flow<List<Student>>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    fun getStudentById(id: Long): Flow<Student?>

    @Query("SELECT * FROM students WHERE id = :id LIMIT 1")
    suspend fun getStudentByIdDirect(id: Long): Student?

    @Query("SELECT * FROM students WHERE studentNumber = :studentNumber LIMIT 1")
    suspend fun getStudentByNumberDirect(studentNumber: String): Student?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: Student): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<Student>): List<Long>

    @Update
    suspend fun updateStudent(student: Student)

    @Query("""
        UPDATE students 
        SET enrollmentStatus = :status, transferDestination = :transferDest, dropReason = :dropReason 
        WHERE id = :studentId
    """)
    suspend fun updateEnrollmentStatus(studentId: Long, status: String, transferDest: String?, dropReason: String?)

    @Delete
    suspend fun deleteStudent(student: Student)

    @Query("SELECT COUNT(*) FROM students")
    suspend fun countStudents(): Int

    // ================= Turmas =================
    @Query("SELECT * FROM classrooms ORDER BY grade ASC, section ASC")
    fun getAllClassrooms(): Flow<List<Classroom>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClassroom(classroom: Classroom): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClassrooms(classrooms: List<Classroom>)

    @Delete
    suspend fun deleteClassroom(classroom: Classroom)

    @Query("SELECT COUNT(*) FROM classrooms")
    suspend fun countClassrooms(): Int

    // ================= Disciplinas =================
    @Query("SELECT * FROM subjects ORDER BY name ASC")
    fun getAllSubjects(): Flow<List<Subject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: Subject): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<Subject>)

    @Query("SELECT COUNT(*) FROM subjects")
    suspend fun countSubjects(): Int

    // --- Limpeza de disciplinas duplicadas (criadas por um erro de arranque duplo) ---
    @Query("SELECT * FROM subjects ORDER BY id ASC")
    suspend fun getAllSubjectsOnce(): List<Subject>

    @Query("UPDATE OR IGNORE grades SET subjectId = :keepId WHERE subjectId = :dupId")
    suspend fun repointGradesSubject(keepId: Long, dupId: Long)

    @Query("UPDATE OR IGNORE attendance_records SET subjectId = :keepId WHERE subjectId = :dupId")
    suspend fun repointAttendanceSubject(keepId: Long, dupId: Long)

    @Query("UPDATE OR IGNORE pauta_locks SET subjectId = :keepId WHERE subjectId = :dupId")
    suspend fun repointLocksSubject(keepId: Long, dupId: Long)

    @Query(
        "DELETE FROM subjects WHERE id = :id " +
            "AND id NOT IN (SELECT subjectId FROM grades) " +
            "AND id NOT IN (SELECT subjectId FROM attendance_records) " +
            "AND id NOT IN (SELECT subjectId FROM pauta_locks)"
    )
    suspend fun deleteSubjectIfUnused(id: Long)

    // ================= Notas / Pautas =================
    @Query("SELECT * FROM grades WHERE studentId = :studentId AND schoolYear = :schoolYear")
    fun getGradesForStudent(studentId: Long, schoolYear: Int = 2026): Flow<List<GradeRecord>>

    @Query("SELECT * FROM grades WHERE studentId IN (:studentIds) AND subjectId = :subjectId AND term = :term")
    fun getGradesForClassAndSubject(studentIds: List<Long>, subjectId: Long, term: Int): Flow<List<GradeRecord>>

    @Query("SELECT * FROM grades WHERE term = :term AND schoolYear = :schoolYear")
    fun getAllGradesForTerm(term: Int, schoolYear: Int = 2026): Flow<List<GradeRecord>>

    @Query("SELECT * FROM grades")
    fun getAllGrades(): Flow<List<GradeRecord>>

    @Query("""
        SELECT * FROM grades 
        WHERE studentId = :studentId AND subjectId = :subjectId AND term = :term AND schoolYear = :schoolYear 
        LIMIT 1
    """)
    suspend fun getGradeDirect(studentId: Long, subjectId: Long, term: Int, schoolYear: Int = 2026): GradeRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateGrade(grade: GradeRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGrades(grades: List<GradeRecord>)

    // ================= Governação e Trava de Pautas (Pós-Conselho) =================
    @Query("SELECT * FROM pauta_locks WHERE gradeClass = :gradeClass AND section = :section AND subjectId = :subjectId AND term = :term LIMIT 1")
    fun getPautaLock(gradeClass: Int, section: String, subjectId: Long, term: Int): Flow<PautaLock?>

    @Query("SELECT * FROM pauta_locks WHERE gradeClass = :gradeClass AND section = :section AND subjectId = :subjectId AND term = :term LIMIT 1")
    suspend fun getPautaLockDirect(gradeClass: Int, section: String, subjectId: Long, term: Int): PautaLock?

    @Query("SELECT * FROM pauta_locks")
    fun getAllPautaLocks(): Flow<List<PautaLock>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateLock(lock: PautaLock)

    // ================= Assiduidade / Presenças =================
    @Query("SELECT * FROM attendance_records WHERE studentId IN (:studentIds) AND subjectId = :subjectId AND date = :date")
    fun getAttendanceForClassAndDate(studentIds: List<Long>, subjectId: Long, date: String): Flow<List<AttendanceRecord>>

    @Query("SELECT * FROM attendance_records WHERE studentId = :studentId")
    fun getAttendanceForStudent(studentId: Long): Flow<List<AttendanceRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAttendance(attendance: AttendanceRecord)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendances(attendances: List<AttendanceRecord>)

    // ================= Notícias e Comunicados (Google Notícias Style) =================
    @Query("SELECT * FROM school_notices ORDER BY id DESC")
    fun getAllNotices(): Flow<List<SchoolNotice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotice(notice: SchoolNotice): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotices(notices: List<SchoolNotice>)

    @Query("SELECT COUNT(*) FROM school_notices")
    suspend fun countNotices(): Int

    // ================= Fórmulas e Pesos SNE =================
    @Query("SELECT * FROM formula_configs ORDER BY cycle ASC")
    fun getAllFormulaConfigs(): Flow<List<FormulaConfig>>

    @Query("SELECT * FROM formula_configs WHERE cycle = :cycle LIMIT 1")
    suspend fun getFormulaConfigDirect(cycle: Int): FormulaConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateFormula(config: FormulaConfig)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFormulas(configs: List<FormulaConfig>)

    // ================= Professores (Fase 2 - Base de Dados) =================
    @Query("SELECT * FROM teachers ORDER BY fullName ASC")
    fun getAllTeachers(): Flow<List<Teacher>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeacher(teacher: Teacher): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeachers(teachers: List<Teacher>)

    @Update
    suspend fun updateTeacher(teacher: Teacher)

    @Delete
    suspend fun deleteTeacher(teacher: Teacher)

    @Query("SELECT COUNT(*) FROM teachers")
    suspend fun countTeachers(): Int
}
