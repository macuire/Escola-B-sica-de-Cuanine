package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.SchoolDao
import com.example.data.model.AttendanceRecord
import com.example.data.model.Classroom
import com.example.data.model.FormulaConfig
import com.example.data.model.GradeRecord
import com.example.data.model.PautaLock
import com.example.data.model.SchoolNotice
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.data.model.Teacher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

@Database(
    entities = [
        Student::class,
        Classroom::class,
        Subject::class,
        GradeRecord::class,
        FormulaConfig::class,
        PautaLock::class,
        SchoolNotice::class,
        AttendanceRecord::class,
        Teacher::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun schoolDao(): SchoolDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        // Impede que o arranque da base de dados e o ViewModel semeiem dados ao mesmo tempo.
        private val seedMutex = Mutex()

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "eb_cuanine_school.db"
                )
                .fallbackToDestructiveMigration()
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed initial data in background coroutine
                        CoroutineScope(Dispatchers.IO).launch {
                            getInstance(context).seedInitialData()
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    /** Remove disciplinas repetidas (mesmo código), mantendo a mais antiga e preservando notas/presenças. */
    private suspend fun removeDuplicateSubjects() {
        val dao = schoolDao()
        val groups = dao.getAllSubjectsOnce().groupBy { it.code }
        for ((_, list) in groups) {
            if (list.size < 2) continue
            val keep = list.first()
            for (dup in list.drop(1)) {
                dao.repointGradesSubject(keep.id, dup.id)
                dao.repointAttendanceSubject(keep.id, dup.id)
                dao.repointLocksSubject(keep.id, dup.id)
                dao.deleteSubjectIfUnused(dup.id)
            }
        }
    }

    suspend fun seedInitialData() {
      seedMutex.withLock {
        val dao = schoolDao()
        removeDuplicateSubjects()
        if (dao.countSubjects() == 0) {
            // SNE Disciplinas Oficiais
            val subjects = listOf(
                Subject(name = "Língua Portuguesa", code = "PORT", applicableCycles = "1,2,3"),
                Subject(name = "Matemática", code = "MAT", applicableCycles = "1,2,3"),
                Subject(name = "Ciências Naturais", code = "CN", applicableCycles = "1,2,3"),
                Subject(name = "Ciências Sociais / História", code = "CS_HIST", applicableCycles = "2,3"),
                Subject(name = "Geografia", code = "GEO", applicableCycles = "3"),
                Subject(name = "Educação Física", code = "ED_FIS", applicableCycles = "1,2,3"),
                Subject(name = "Educação Visual", code = "ED_VIS", applicableCycles = "1,2,3"),
                Subject(name = "Língua Inglesa", code = "ING", applicableCycles = "3"),
                Subject(name = "Física", code = "FIS", applicableCycles = "3"),
                Subject(name = "Química", code = "QUI", applicableCycles = "3"),
                Subject(name = "Biologia", code = "BIO", applicableCycles = "3")
            )
            dao.insertSubjects(subjects)
        }

        if (dao.countClassrooms() == 0) {
            // Turmas nos 3 ciclos da EB Cuanine
            val classrooms = listOf(
                // 1.º Ciclo (1ª e 2ª classes)
                Classroom(cycle = 1, grade = 1, section = "A", roomName = "Sala 1 - Bloco A", classTeacher = "Prof.ª Helena Cossa", shift = "Manhã"),
                Classroom(cycle = 1, grade = 2, section = "A", roomName = "Sala 2 - Bloco A", classTeacher = "Prof. Carlos Mondlane", shift = "Manhã"),
                // 2.º Ciclo (3ª à 5ª classes)
                Classroom(cycle = 2, grade = 3, section = "A", roomName = "Sala 3 - Bloco B", classTeacher = "Prof.ª Graça Macamo", shift = "Manhã"),
                Classroom(cycle = 2, grade = 4, section = "A", roomName = "Sala 4 - Bloco B", classTeacher = "Prof. Ernesto Sitoe", shift = "Tarde"),
                Classroom(cycle = 2, grade = 5, section = "A", roomName = "Sala 5 - Bloco B", classTeacher = "Prof.ª Teresa Matsinhe", shift = "Manhã"),
                // 3.º Ciclo (6ª à 10ª classes)
                Classroom(cycle = 3, grade = 6, section = "A", roomName = "Sala 6 - Bloco C", classTeacher = "Prof. Salomão Langa", shift = "Manhã"),
                Classroom(cycle = 3, grade = 7, section = "A", roomName = "Sala 7 - Bloco C", classTeacher = "Prof.ª Beatriz Tembe", shift = "Tarde"),
                Classroom(cycle = 3, grade = 8, section = "A", roomName = "Sala 8 - Bloco D", classTeacher = "Prof. Américo Nhaca", shift = "Manhã"),
                Classroom(cycle = 3, grade = 9, section = "A", roomName = "Sala 9 - Bloco D", classTeacher = "Prof.ª Joana Mabunda", shift = "Tarde"),
                Classroom(cycle = 3, grade = 10, section = "A", roomName = "Sala 10 - Bloco D", classTeacher = "Prof. Pedro Munguambe", shift = "Manhã")
            )
            dao.insertClassrooms(classrooms)
        }

        // Fórmulas e Pesos Iniciais SNE
        val formulas = listOf(
            FormulaConfig(
                cycle = 1,
                cycleName = "1.º Ciclo (1.ª e 2.ª Classes)",
                acs1Weight = 1.0,
                acs2Weight = 1.0,
                atWeight = 1.0,
                examWeight = 0.0,
                minPassGrade = 10.0,
                formulaDescription = "Avaliação Contínua e Descritiva (MB, B, S, NS)",
                isQualitative = true
            ),
            FormulaConfig(
                cycle = 2,
                cycleName = "2.º Ciclo (3.ª à 5.ª Classes)",
                acs1Weight = 1.0,
                acs2Weight = 1.0,
                atWeight = 2.0,
                examWeight = 1.0,
                minPassGrade = 10.0,
                formulaDescription = "MT = (ACS1 + ACS2 + 2*AT) / 4; Média Ciclo com Prova",
                isQualitative = false
            ),
            FormulaConfig(
                cycle = 3,
                cycleName = "3.º Ciclo (6.ª à 10.ª Classes)",
                acs1Weight = 1.0,
                acs2Weight = 1.0,
                atWeight = 2.0,
                examWeight = 2.0,
                minPassGrade = 10.0,
                formulaDescription = "MT = (ACS1 + ACS2 + 2*AT) / 4; MA = (MT1 + MT2 + MT3)/3 ou Exame",
                isQualitative = false
            )
        )
        dao.insertFormulas(formulas)

        // Seed Notícias e Comunicados Estilo Google Notícias
        if (dao.countNotices() == 0) {
            val notices = listOf(
                SchoolNotice(
                    title = "Conselho de Notas do 1.º Trimestre e Fecho das Pautas",
                    summary = "A Direcção Pedagógica informa que a reunião do Conselho de Notas realiza-se na sexta-feira. Todas as pautas passarão ao modo 'Apenas Leitura' após deliberação.",
                    body = "Nos termos do Regulamento de Avaliação do Ensino Básico (MINEDH), a validação das pautas de frequência do 1.º Trimestre decorrerá entre os dias 14 e 16 do mês corrente. Os professores deverão certificar o preenchimento de todas as ACS e AT até ao limite estipulado.",
                    category = "Conselho de Notas",
                    publishDate = "Hoje, 08:30",
                    priority = "DESTAQUE",
                    author = "Direcção Pedagógica"
                ),
                SchoolNotice(
                    title = "Reunião Geral com Pais e Encarregados de Educação",
                    summary = "Assembleia geral na sala magna da EB Cuanine para prestação de contas do Conselho de Escola e entrega de prémios aos melhores estudantes do Quadro de Honra.",
                    body = "Convocam-se todos os pais e encarregados de educação da comunidade de Cuanine e bairros vizinhos para a sessão trimestral com o corpo docente e direcção.",
                    category = "Comunidade",
                    publishDate = "Ontem",
                    priority = "NORMAL",
                    author = "Conselho de Escola"
                ),
                SchoolNotice(
                    title = "Campanha de Saúde Escolar e Higiene no Posto de Cuanine",
                    summary = "Em colaboração com o Centro de Saúde da Manhiça, decorrerá triagem visual e administração de desparasitantes aos alunos do 1.º e 2.º Ciclos.",
                    body = "Os alunos das 1.ª às 5.ª classes participarão das sessões de sensibilização sobre água potável e prevenção de doenças sazonais.",
                    category = "Saúde Escolar",
                    publishDate = "Há 2 dias",
                    priority = "NORMAL",
                    author = "Comissão de Saúde"
                ),
                SchoolNotice(
                    title = "Inscrições Abertas para as Olimpíadas Distritais de Matemática",
                    summary = "Alunos da 7.ª e 10.ª classes representarão a Escola Básica de Cuanine na fase distrital na vila da Manhiça.",
                    body = "Os estudantes com médias iguais ou superiores a 15 valores em Matemática foram pré-selecionados para a fase preparatória.",
                    category = "Desporto e Ciência",
                    publishDate = "Há 4 dias",
                    priority = "NORMAL",
                    author = "Núcleo de Ciências Exactas"
                )
            )
            dao.insertNotices(notices)
        }

        if (dao.countStudents() == 0) {
            // Alunos de amostra representando os 3 ciclos e diferentes estados de matrícula
            val sampleStudents = listOf(
                // 1º Ciclo
                Student(
                    studentNumber = "EBC-2026-001",
                    fullName = "Aníbal Jaime Cossa",
                    birthDate = "2019-03-14",
                    gender = "M",
                    guardianName = "Jaime Cossa",
                    guardianPhone = "+258 84 123 4567",
                    address = "Bairro Cuanine Centro, Manhiça",
                    cycle = 1,
                    gradeClass = 1,
                    section = "A",
                    docType = "Cédula Pessoal",
                    docNumber = "CED-4491/2019",
                    accessPin = "1111",
                    enrollmentStatus = "ACTIVO"
                ),
                Student(
                    studentNumber = "EBC-2026-002",
                    fullName = "Fatima Zacarias Matsinhe",
                    birthDate = "2018-08-22",
                    gender = "F",
                    guardianName = "Zacarias Matsinhe",
                    guardianPhone = "+258 86 987 6543",
                    address = "Estrada Principal Cuanine, Manhiça",
                    cycle = 1,
                    gradeClass = 2,
                    section = "A",
                    docType = "Certidão de Nascimento",
                    docNumber = "CERT-8812/2018",
                    accessPin = "2222",
                    enrollmentStatus = "ACTIVO"
                ),
                // 2º Ciclo
                Student(
                    studentNumber = "EBC-2026-003",
                    fullName = "Délcio Fernando Sitoe",
                    birthDate = "2016-01-10",
                    gender = "M",
                    guardianName = "Fernando Sitoe",
                    guardianPhone = "+258 82 345 6789",
                    address = "Zona Baixa Incomáti, Cuanine",
                    cycle = 2,
                    gradeClass = 4,
                    section = "A",
                    docType = "BI",
                    docNumber = "110100458921B",
                    accessPin = "3333",
                    enrollmentStatus = "ACTIVO"
                ),
                Student(
                    studentNumber = "EBC-2026-004",
                    fullName = "Esperança Paulo Mondlane",
                    birthDate = "2015-11-05",
                    gender = "F",
                    guardianName = "Paulo Mondlane",
                    guardianPhone = "+258 84 555 4321",
                    address = "Bairro Josina Machel, Manhiça",
                    cycle = 2,
                    gradeClass = 5,
                    section = "A",
                    docType = "BI",
                    docNumber = "110100789456M",
                    accessPin = "4444",
                    enrollmentStatus = "ACTIVO"
                ),
                // 3º Ciclo
                Student(
                    studentNumber = "EBC-2026-005",
                    fullName = "Armando Zacarias Macamo",
                    birthDate = "2013-04-18",
                    gender = "M",
                    guardianName = "Zacarias Macamo",
                    guardianPhone = "+258 87 654 3210",
                    address = "Cuanine Linha Férrea, Manhiça",
                    cycle = 3,
                    gradeClass = 7,
                    section = "A",
                    docType = "BI",
                    docNumber = "110100234567A",
                    accessPin = "5555",
                    enrollmentStatus = "ACTIVO"
                ),
                Student(
                    studentNumber = "EBC-2026-006",
                    fullName = "Samira Isaías Tembe",
                    birthDate = "2010-09-30",
                    gender = "F",
                    guardianName = "Isaías Tembe",
                    guardianPhone = "+258 84 789 0123",
                    address = "Vila da Manhiça, Bairro 3",
                    cycle = 3,
                    gradeClass = 10,
                    section = "A",
                    docType = "BI",
                    docNumber = "110100654321C",
                    accessPin = "6666",
                    enrollmentStatus = "ACTIVO"
                ),
                Student(
                    studentNumber = "EBC-2026-007",
                    fullName = "Geraldo Mário Langa",
                    birthDate = "2010-06-12",
                    gender = "M",
                    guardianName = "Mário Langa",
                    guardianPhone = "+258 85 111 2233",
                    address = "Cuanine Bloco 4, Manhiça",
                    cycle = 3,
                    gradeClass = 10,
                    section = "A",
                    docType = "BI",
                    docNumber = "110100998877D",
                    accessPin = "7777",
                    enrollmentStatus = "ACTIVO"
                ),
                // Aluno Transferido
                Student(
                    studentNumber = "EBC-2026-008",
                    fullName = "Júlio Tomás Nhaca",
                    birthDate = "2012-07-19",
                    gender = "M",
                    guardianName = "Tomás Nhaca",
                    guardianPhone = "+258 84 999 1122",
                    address = "Posto Administrativo Manhiça",
                    cycle = 3,
                    gradeClass = 8,
                    section = "A",
                    docType = "BI",
                    docNumber = "110100334455N",
                    accessPin = "8888",
                    enrollmentStatus = "TRANSFERIDO",
                    transferDestination = "EPC Manhiça-Sede (Guia N.º 42/2026)"
                ),
                // Aluno Desistido
                Student(
                    studentNumber = "EBC-2026-009",
                    fullName = "Margarida Felizarda Mabunda",
                    birthDate = "2014-02-11",
                    gender = "F",
                    guardianName = "Felizardo Mabunda",
                    guardianPhone = "+258 86 333 4455",
                    address = "Zona Agrícola Incomáti, Cuanine",
                    cycle = 2,
                    gradeClass = 5,
                    section = "A",
                    docType = "Cédula Pessoal",
                    docNumber = "CED-9912/2014",
                    accessPin = "9999",
                    enrollmentStatus = "DESISTIDO",
                    dropReason = "Deslocação familiar para campanha agrícola de cana-de-açúcar"
                )
            )
            val studentIds = dao.insertStudents(sampleStudents)

            // Seed sample grades for Term 1 (1.º Trimestre 2026)
            if (studentIds.size >= 7) {
                val s1 = studentIds[0]
                val s2 = studentIds[1]
                val s3 = studentIds[2]
                val s4 = studentIds[3]
                val s5 = studentIds[4]
                val s6 = studentIds[5]
                val s7 = studentIds[6]

                val initialGrades = listOf(
                    GradeRecord(studentId = s1, subjectId = 1, term = 1, qualitative = "Muito Bom", termAverage = 18.0),
                    GradeRecord(studentId = s1, subjectId = 2, term = 1, qualitative = "Bom", termAverage = 15.0),
                    GradeRecord(studentId = s2, subjectId = 1, term = 1, qualitative = "Bom", termAverage = 14.0),
                    GradeRecord(studentId = s2, subjectId = 2, term = 1, qualitative = "Muito Bom", termAverage = 17.0),
                    GradeRecord(studentId = s3, subjectId = 1, term = 1, acs1 = 13.0, acs2 = 14.0, at = 15.0, termAverage = 14.25),
                    GradeRecord(studentId = s3, subjectId = 2, term = 1, acs1 = 11.0, acs2 = 12.0, at = 13.0, termAverage = 12.25),
                    GradeRecord(studentId = s4, subjectId = 1, term = 1, acs1 = 16.0, acs2 = 17.0, at = 16.0, termAverage = 16.25),
                    GradeRecord(studentId = s4, subjectId = 2, term = 1, acs1 = 15.0, acs2 = 16.0, at = 17.0, termAverage = 16.25),
                    GradeRecord(studentId = s5, subjectId = 1, term = 1, acs1 = 12.0, acs2 = 13.0, at = 14.0, termAverage = 13.25),
                    GradeRecord(studentId = s5, subjectId = 2, term = 1, acs1 = 10.0, acs2 = 11.0, at = 12.0, termAverage = 11.25),
                    GradeRecord(studentId = s6, subjectId = 1, term = 1, acs1 = 17.0, acs2 = 18.0, at = 17.0, termAverage = 17.25),
                    GradeRecord(studentId = s6, subjectId = 2, term = 1, acs1 = 16.0, acs2 = 15.0, at = 16.0, termAverage = 15.75),
                    GradeRecord(studentId = s6, subjectId = 3, term = 1, acs1 = 15.0, acs2 = 16.0, at = 15.0, termAverage = 15.25),
                    GradeRecord(studentId = s7, subjectId = 1, term = 1, acs1 = 11.0, acs2 = 12.0, at = 10.0, termAverage = 10.75),
                    GradeRecord(studentId = s7, subjectId = 2, term = 1, acs1 = 8.0, acs2 = 9.0, at = 9.0, termAverage = 8.75)
                )
                dao.insertGrades(initialGrades)
            }
        }

        if (dao.countTeachers() == 0) {
            val teachers = listOf(
                Teacher(
                    teacherCode = "DOC-EBC-01",
                    fullName = "Prof.ª Helena Cossa",
                    gender = "F",
                    phone = "+258 84 123 4501",
                    contractType = "Efectivo",
                    category = "Docente N1",
                    assignedClassroom = "Sala 1 - Bloco A (1.ª Classe)",
                    mainSubjects = "Língua Portuguesa, Matemática",
                    bio = "Mais de 15 anos de dedicação ao ensino inicial na comunidade de Cuanine."
                ),
                Teacher(
                    teacherCode = "DOC-EBC-02",
                    fullName = "Prof. Carlos Mondlane",
                    gender = "M",
                    phone = "+258 84 123 4502",
                    contractType = "Efectivo",
                    category = "Docente N1",
                    assignedClassroom = "Sala 2 - Bloco A (2.ª Classe)",
                    mainSubjects = "Língua Portuguesa, Matemática",
                    bio = "Especialista em alfabetização e cálculo básico infantil no distrito da Manhiça."
                ),
                Teacher(
                    teacherCode = "DOC-EBC-03",
                    fullName = "Prof.ª Graça Macamo",
                    gender = "F",
                    phone = "+258 84 123 4503",
                    contractType = "Efectivo",
                    category = "Docente N2",
                    assignedClassroom = "Sala 3 - Bloco B (3.ª Classe)",
                    mainSubjects = "Ciências Naturais, Ciências Sociais",
                    bio = "Coordena o clube escolar de leitura e ciências da natureza."
                ),
                Teacher(
                    teacherCode = "DOC-EBC-04",
                    fullName = "Prof. Ernesto Sitoe",
                    gender = "M",
                    phone = "+258 84 123 4504",
                    contractType = "Contratado",
                    category = "Docente N2",
                    assignedClassroom = "Sala 4 - Bloco B (4.ª Classe)",
                    mainSubjects = "Língua Portuguesa, História",
                    bio = "Dinamizador de atividades desportivas e comunitárias na escola."
                ),
                Teacher(
                    teacherCode = "DOC-EBC-05",
                    fullName = "Prof. Salomão Langa",
                    gender = "M",
                    phone = "+258 84 123 4505",
                    contractType = "Efectivo",
                    category = "Docente N1",
                    assignedClassroom = "Sala 6 - Bloco C (6.ª Classe)",
                    mainSubjects = "Matemática, Física",
                    bio = "Responsável pela preparação dos alunos para as olimpíadas distritais de matemática."
                )
            )
            dao.insertTeachers(teachers)
        }
    }
      }
}
