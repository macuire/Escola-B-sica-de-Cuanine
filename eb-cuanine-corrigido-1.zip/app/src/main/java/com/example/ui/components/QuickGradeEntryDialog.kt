package com.example.ui.components

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FormulaConfig
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.SneCalculator
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickGradeEntryDialog(
    student: Student,
    subjects: List<Subject>,
    formulaConfigs: List<FormulaConfig>,
    onSaveGrade: (subjectId: Long, term: Int, acs1: Double?, acs2: Double?, at: Double?, exam: Double?, qualitative: String?) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedSubjectId by remember { mutableStateOf(subjects.firstOrNull()?.id ?: 1L) }
    var selectedTerm by remember { mutableIntStateOf(1) }
    var subjectExpanded by remember { mutableStateOf(false) }

    var acs1Text by remember { mutableStateOf("") }
    var acs2Text by remember { mutableStateOf("") }
    var atText by remember { mutableStateOf("") }
    var examText by remember { mutableStateOf("") }
    var qualitativeText by remember { mutableStateOf("Bom") }

    val cycle = student.cycle
    val formulaConfig = formulaConfigs.find { it.cycle == cycle }

    // Speech-to-Text Launcher para ditado por voz de notas
    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenTexts = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spoken = spokenTexts?.firstOrNull()?.trim() ?: ""
            if (spoken.isNotBlank()) {
                // Tenta extrair número falado (ex: "15", "14.5", "dezessete")
                val cleanNumber = spoken.replace(",", ".").filter { it.isDigit() || it == '.' }
                val numVal = cleanNumber.toDoubleOrNull()
                if (numVal != null && numVal in 0.0..20.0) {
                    when {
                        acs1Text.isBlank() -> acs1Text = cleanNumber
                        acs2Text.isBlank() -> acs2Text = cleanNumber
                        atText.isBlank() -> atText = cleanNumber
                        else -> atText = cleanNumber
                    }
                    Toast.makeText(context, "Nota ditada por voz: $cleanNumber", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Texto reconhecido: '$spoken'. Dite uma nota de 0 a 20.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun startVoiceDictation() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-MZ")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Dite a nota do aluno (ex: 14 ou 16.5)")
        }
        try {
            speechRecognizerLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Reconhecimento de voz indisponível no dispositivo.", Toast.LENGTH_SHORT).show()
        }
    }

    val calculatedAvg by remember {
        derivedStateOf {
            val a1 = acs1Text.toDoubleOrNull()
            val a2 = acs2Text.toDoubleOrNull()
            val at = atText.toDoubleOrNull()
            SneCalculator.calculateTermAverage(cycle, a1, a2, at, formulaConfig)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(CuanineNavy),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color.White
                    )
                }
                Column {
                    Text(
                        text = "Lançamento Rápido de Notas",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${student.fullName} (${student.studentNumber})",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Info da turma e ciclo
                Text(
                    text = "${student.gradeClass}.ª Classe '${student.section}' | ${SneCalculator.getCycleTitle(student.cycle)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Seleção de Disciplina
                val currentSubject = subjects.find { it.id == selectedSubjectId } ?: subjects.firstOrNull()
                ExposedDropdownMenuBox(
                    expanded = subjectExpanded,
                    onExpandedChange = { subjectExpanded = it },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = currentSubject?.name ?: "Selecione a Disciplina",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Disciplina") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = subjectExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = subjectExpanded,
                        onDismissRequest = { subjectExpanded = false }
                    ) {
                        subjects.forEach { sub ->
                            DropdownMenuItem(
                                text = { Text(sub.name) },
                                onClick = {
                                    selectedSubjectId = sub.id
                                    subjectExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Seleção de Trimestre
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(1, 2, 3).forEach { term ->
                        FilterChip(
                            selected = selectedTerm == term,
                            onClick = { selectedTerm = term },
                            label = { Text("$term.º Trim.") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Linha com Botão de Ditado por Voz
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Notas da Avaliação (0 - 20)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    FilledIconButton(
                        onClick = { startVoiceDictation() },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = GoldAccent,
                            contentColor = Color.White
                        ),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Ditar Notas por Voz",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (cycle == 1) {
                    // 1º Ciclo: Menção Qualitativa
                    Text(
                        text = "Avaliação Descritiva (1.º Ciclo do SNE):",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Muito Bom", "Bom", "Suficiente", "Não Suficiente").forEach { mention ->
                            val isSel = qualitativeText == mention
                            FilterChip(
                                selected = isSel,
                                onClick = { qualitativeText = mention },
                                label = { Text(mention, fontSize = 10.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    // 2º e 3º Ciclo: Lançamento de ACS1, ACS2, AT e Exame
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = acs1Text,
                            onValueChange = { acs1Text = it },
                            label = { Text("ACS 1") },
                            placeholder = { Text("0-20") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("acs1_input")
                        )
                        OutlinedTextField(
                            value = acs2Text,
                            onValueChange = { acs2Text = it },
                            label = { Text("ACS 2") },
                            placeholder = { Text("0-20") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("acs2_input")
                        )
                        OutlinedTextField(
                            value = atText,
                            onValueChange = { atText = it },
                            label = { Text("AT") },
                            placeholder = { Text("0-20") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("at_input")
                        )
                    }

                    if (student.gradeClass in listOf(7, 10)) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = examText,
                            onValueChange = { examText = it },
                            label = { Text("Exame Nacional / Prova Final") },
                            placeholder = { Text("0-20") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Caixa de Média Automática Calculada
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Calculate,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Média Trimestral (SNE):",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            val avgVal = calculatedAvg
                            if (avgVal != null) {
                                val isPass = avgVal >= 10.0
                                Text(
                                    text = "${String.format(Locale.US, "%.1f", avgVal)} Val. (${if (isPass) "Aprovado" else "Reprovado"})",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPass) AcademicGreen else AcademicRed
                                )
                            } else {
                                Text(
                                    text = "A calcular...",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSaveGrade(
                        selectedSubjectId,
                        selectedTerm,
                        acs1Text.toDoubleOrNull(),
                        acs2Text.toDoubleOrNull(),
                        atText.toDoubleOrNull(),
                        examText.toDoubleOrNull(),
                        if (cycle == 1) qualitativeText else null
                    )
                    onDismiss()
                },
                modifier = Modifier.testTag("save_grade_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Gravar Nota")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}
