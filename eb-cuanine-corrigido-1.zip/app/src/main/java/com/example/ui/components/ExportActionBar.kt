package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicRed

/**
 * Barra Dual de Exportação Rápida obrigatória (Word .docx e PDF .pdf).
 * Visível e com destaque em todas as telas de emissão.
 */
@Composable
fun ExportActionBar(
    onExportPdf: () -> Unit,
    onExportDocx: () -> Unit,
    modifier: Modifier = Modifier,
    pdfLabel: String = "Exportar em PDF (.pdf)",
    docxLabel: String = "Exportar em Word (.docx)"
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Botão PDF
        Button(
            onClick = onExportPdf,
            colors = ButtonDefaults.buttonColors(
                containerColor = AcademicRed,
                contentColor = Color.White
            ),
            modifier = Modifier
                .weight(1f)
                .testTag("export_pdf_button")
        ) {
            Icon(
                imageVector = Icons.Default.PictureAsPdf,
                contentDescription = "PDF Icon",
                modifier = Modifier.padding(end = 6.dp)
            )
            Text(
                text = pdfLabel,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }

        // Botão Word .docx (100% editável no Word e WPS)
        Button(
            onClick = onExportDocx,
            colors = ButtonDefaults.buttonColors(
                containerColor = AcademicBlue,
                contentColor = Color.White
            ),
            modifier = Modifier
                .weight(1f)
                .testTag("export_docx_button")
        ) {
            Icon(
                imageVector = Icons.Default.Description,
                contentDescription = "Word Icon",
                modifier = Modifier.padding(end = 6.dp)
            )
            Text(
                text = docxLabel,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}
