package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Class
import androidx.compose.material.icons.filled.Female
import androidx.compose.material.icons.filled.Male
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.ui.components.ExportActionBar
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.DocxExporter
import com.example.util.PdfExporter
import com.example.util.SneCalculator
import java.util.Locale

@Composable
fun DirectionScreen(
    students: List<Student>,
    classrooms: List<Classroom>,
    subjects: List<Subject>,
    grades: List<GradeRecord>,
    onStudentClick: (Student) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val totalStudents = students.size
    val maleCount = students.count { it.gender.equals("M", ignoreCase = true) }
    val femaleCount = students.count { it.gender.equals("F", ignoreCase = true) }

    // Alunos com médias calculadas
    val studentsWithGrades = students.filter { st ->
        grades.any { it.studentId == st.id && it.termAverage != null }
    }
    val passingStudents = studentsWithGrades.count { st ->
        val stGrades = grades.filter { it.studentId == st.id && it.termAverage != null }
        val avg = stGrades.mapNotNull { it.termAverage }.average()
        avg >= 10.0
    }
    val passRatePercent = if (studentsWithGrades.isNotEmpty()) {
        (passingStudents.toDouble() / studentsWithGrades.size) * 100.0
    } else 88.5

    fun exportSchoolReportPdf() {
        // Gera pauta da turma representativa ou relatório em PDF
        val sampleClass = classrooms.firstOrNull() ?: Classroom(cycle = 3, grade = 10, section = "A", roomName = "Sala 1", classTeacher = "Prof. Mondlane")
        val sampleSub = subjects.firstOrNull() ?: Subject(name = "Língua Portuguesa", code = "PORT")
        val gradesMap = grades.filter { it.subjectId == sampleSub.id }.associateBy { it.studentId }
        val file = PdfExporter.exportPautaPdf(context, sampleClass, sampleSub, 1, students, gradesMap)
        PdfExporter.shareFile(context, file)
    }

    fun exportSchoolReportDocx() {
        val sampleClass = classrooms.firstOrNull() ?: Classroom(cycle = 3, grade = 10, section = "A", roomName = "Sala 1", classTeacher = "Prof. Mondlane")
        val sampleSub = subjects.firstOrNull() ?: Subject(name = "Língua Portuguesa", code = "PORT")
        val gradesMap = grades.filter { it.subjectId == sampleSub.id }.associateBy { it.studentId }
        val file = DocxExporter.exportPautaDocx(context, sampleClass, sampleSub, 1, students, gradesMap)
        DocxExporter.shareDocx(context, file)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Título e Cabeçalho
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CuanineNavy),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Painel da Direcção Escolar",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Estatísticas globais e rendimento por ciclos do SNE • Escola Básica de Cuanine",
                        fontSize = 12.sp,
                        color = GoldAccent
                    )
                }
            }
        }

        // Ações Rápidas de Exportação Dual (Word & PDF)
        item {
            ExportActionBar(
                onExportPdf = { exportSchoolReportPdf() },
                onExportDocx = { exportSchoolReportDocx() },
                pdfLabel = "Relatório Escolar (.pdf)",
                docxLabel = "Relatório Editável (.docx)"
            )
        }

        // Cartões de Estatísticas Principais
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Total Alunos",
                    value = "$totalStudents",
                    subtitle = "Matriculados",
                    icon = Icons.Default.People,
                    iconColor = AcademicBlue,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Turmas Activas",
                    value = "${classrooms.size}",
                    subtitle = "1.ª à 10.ª Classe",
                    icon = Icons.Default.Class,
                    iconColor = GoldAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Taxa Rendimento",
                    value = "${String.format(Locale.US, "%.1f", passRatePercent)}%",
                    subtitle = "$passingStudents de ${studentsWithGrades.size} aptos",
                    icon = Icons.Default.CheckCircle,
                    iconColor = AcademicGreen,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Género (M / F)",
                    value = "$maleCount / $femaleCount",
                    subtitle = "Equilíbrio escolar",
                    icon = Icons.Default.School,
                    iconColor = AcademicEmerald,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Desempenho e Distribuição pelos 3 Ciclos do SNE
        item {
            Text(
                text = "Estruturação por Ciclos do SNE (Moçambique)",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        item {
            listOf(1, 2, 3).forEach { cycleNum ->
                val cycleStudents = students.filter { it.cycle == cycleNum }
                val cycleTitle = SneCalculator.getCycleTitle(cycleNum)
                val cycleSubtitle = when (cycleNum) {
                    1 -> "Avaliação Contínua e Descritiva"
                    2 -> "Avaliação Contínua + Provas de Ciclo"
                    else -> "Pautas com ACS, AT, Exames e Médias"
                }

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = cycleTitle,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CuanineNavy
                                )
                                Text(
                                    text = cycleSubtitle,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${cycleStudents.size} Alunos",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        val ratio = if (totalStudents > 0) cycleStudents.size.toFloat() / totalStudents else 0.33f
                        LinearProgressIndicator(
                            progress = { ratio },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = when (cycleNum) {
                                1 -> AcademicEmerald
                                2 -> GoldAccent
                                else -> CuanineNavy
                            }
                        )
                    }
                }
            }
        }

        // Lista de Turmas da Escola Básica de Cuanine
        item {
            Text(
                text = "Turmas e Professores Regentes",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        items(classrooms) { cr ->
            val countInClass = students.count { it.gradeClass == cr.grade && it.section == cr.section }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "${cr.grade}.ª Classe '${cr.section}' • ${cr.shift}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Docente: ${cr.classTeacher} • ${cr.roomName}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "$countInClass alunos",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Painel Estatístico de Movimentação Escolar e Retenção (MINEDH)
        item {
            val activeCount = students.count { it.enrollmentStatus == "ACTIVO" }
            val transferredCount = students.count { it.enrollmentStatus == "TRANSFERIDO" }
            val droppedCount = students.count { it.enrollmentStatus == "DESISTIDO" }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Movimentação Escolar e Retenção (MINEDH)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CuanineNavy
                    )
                    Text(
                        text = "Monitoria de desistências e transferências para controlo da taxa de retenção",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatCard(
                            title = "Activos",
                            value = "$activeCount",
                            subtitle = "${if (students.isNotEmpty()) (activeCount * 100 / students.size) else 0}% frequência",
                            icon = Icons.Default.CheckCircle,
                            iconColor = AcademicGreen,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "Transferidos",
                            value = "$transferredCount",
                            subtitle = "Outras escolas",
                            icon = Icons.Default.School,
                            iconColor = AcademicBlue,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            title = "Desistidos",
                            value = "$droppedCount",
                            subtitle = "Abandono escolar",
                            icon = Icons.Default.People,
                            iconColor = AcademicRed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Acesso Rápido às Fichas dos Estudantes
        item {
            Text(
                text = "Fichas Individuais dos Estudantes (Clique para abrir Ficha Completa):",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        items(students.take(15)) { st ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onStudentClick(st) }
                    .padding(vertical = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = st.fullName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${st.studentNumber} • ${st.gradeClass}.ª '${st.section}' • Enc: ${st.guardianName}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                when (st.enrollmentStatus) {
                                    "ACTIVO" -> AcademicGreen.copy(alpha = 0.15f)
                                    "TRANSFERIDO" -> AcademicBlue.copy(alpha = 0.15f)
                                    else -> AcademicRed.copy(alpha = 0.15f)
                                }
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = st.enrollmentStatus,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (st.enrollmentStatus) {
                                "ACTIVO" -> AcademicGreen
                                "TRANSFERIDO" -> AcademicBlue
                                else -> AcademicRed
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(iconColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
