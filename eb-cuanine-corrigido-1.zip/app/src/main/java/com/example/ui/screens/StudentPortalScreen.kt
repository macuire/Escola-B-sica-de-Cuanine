package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.data.model.Subject
import com.example.ui.components.ExportActionBar
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.AcademicRed
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.DocxExporter
import com.example.util.PdfExporter
import com.example.util.SneCalculator
import java.io.File
import java.util.Locale

@Composable
fun StudentPortalScreen(
    loggedInStudent: Student?,
    allStudents: List<Student>,
    subjects: List<Subject>,
    grades: List<GradeRecord>,
    onLogin: (studentNumberOrDoc: String, pin: String, (Boolean) -> Unit) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var studentNumberInput by remember { mutableStateOf("") }
    var pinInput by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf<String?>(null) }

    if (loggedInStudent == null) {
        // Tela de Acesso por Senha do Aluno / Encarregado
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            item {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(CuanineNavy),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.School,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(44.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Portal do Aluno e Encarregado",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = CuanineNavy
                )
                Text(
                    text = "Consulte as notas, pautas e boletim escolar da EB Cuanine",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(24.dp))
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        OutlinedTextField(
                            value = studentNumberInput,
                            onValueChange = {
                                studentNumberInput = it
                                loginError = null
                            },
                            label = { Text("N.º de Matrícula ou BI") },
                            placeholder = { Text("ex: EBC-2026-001 ou 110100458921B") },
                            singleLine = true,
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Person, contentDescription = null)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("student_login_number")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = {
                                pinInput = it
                                loginError = null
                            },
                            label = { Text("Senha / PIN Pessoal") },
                            placeholder = { Text("ex: 1111 ou 1234") },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            singleLine = true,
                            leadingIcon = {
                                Icon(imageVector = Icons.Default.Lock, contentDescription = null)
                            },
                            isError = loginError != null,
                            supportingText = {
                                if (loginError != null) {
                                    Text(text = loginError!!, color = MaterialTheme.colorScheme.error)
                                } else {
                                    Text("PIN predefinido: 1111 (Aníbal), 2222 (Fatima), 3333 (Délcio)", fontSize = 10.sp)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("student_login_pin")
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                onLogin(studentNumberInput, pinInput) { success ->
                                    if (!success) {
                                        loginError = "N.º de matrícula ou senha incorrectos."
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CuanineNavy),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("student_login_button")
                        ) {
                            Text("Aceder às Minhas Notas", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }

            // Acesso Rápido de Demonstração
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "Ou selecione um aluno para demonstração rápida:",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    allStudents.take(3).forEach { sample ->
                        OutlinedButton(
                            onClick = {
                                onLogin(sample.studentNumber, sample.accessPin) {}
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(sample.fullName.split(" ").first(), fontSize = 11.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    } else {
        // Aluno Conectado: Boletim Individual de Aproveitamento
        val studentGrades = grades.filter { it.studentId == loggedInStudent.id }

        fun exportBoletimPdf() {
            val file = PdfExporter.exportBoletimPdf(context, loggedInStudent, subjects, studentGrades)
            PdfExporter.shareFile(context, file)
        }

        fun exportBoletimDocx() {
            val file = DocxExporter.exportBoletimDocx(context, loggedInStudent, subjects, studentGrades)
            DocxExporter.shareDocx(context, file)
        }

        fun exportMatriculaCert() {
            val file = PdfExporter.exportCertificadoMatriculaPdf(context, loggedInStudent)
            PdfExporter.shareFile(context, file)
        }

        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Cartão de Identificação do Aluno
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CuanineNavy),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                val localBmp = remember(loggedInStudent.photoUri) {
                                    if (loggedInStudent.photoUri != null && File(loggedInStudent.photoUri).exists()) {
                                        BitmapFactory.decodeFile(loggedInStudent.photoUri)
                                    } else null
                                }
                                if (localBmp != null) {
                                    Image(
                                        bitmap = localBmp.asImageBitmap(),
                                        contentDescription = "Foto do Aluno",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .border(2.dp, GoldAccent, CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(GoldAccent),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = loggedInStudent.fullName.take(1),
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = CuanineNavy
                                        )
                                    }
                                }

                                Column {
                                    Text(
                                        text = loggedInStudent.fullName,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "N.º ${loggedInStudent.studentNumber} • ${loggedInStudent.gradeClass}.ª Classe '${loggedInStudent.section}'",
                                        fontSize = 12.sp,
                                        color = GoldAccent
                                    )
                                    Text(
                                        text = SneCalculator.getCycleTitle(loggedInStudent.cycle),
                                        fontSize = 11.sp,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                }
                            }

                            IconButton(onClick = onLogout) {
                                Icon(
                                    imageVector = Icons.Default.ExitToApp,
                                    contentDescription = "Terminar Sessão",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }

            // Botões de Ação Rápida de Exportação Dual (Word & PDF)
            item {
                ExportActionBar(
                    onExportPdf = { exportBoletimPdf() },
                    onExportDocx = { exportBoletimDocx() },
                    pdfLabel = "Boletim em PDF (.pdf)",
                    docxLabel = "Boletim em Word (.docx)"
                )
            }

            // Emitir Declaração de Matrícula
            item {
                OutlinedButton(
                    onClick = { exportMatriculaCert() },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(imageVector = Icons.Default.Description, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Emitir Declaração de Matrícula Oficial (.pdf)", fontSize = 12.sp)
                }
            }

            // Tabela com Notas por Disciplina e Trimestre
            item {
                Text(
                    text = "Aproveitamento Escolar por Disciplina (Ano Lectivo 2026)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            items(subjects) { sub ->
                val g1 = studentGrades.find { it.subjectId == sub.id && it.term == 1 }
                val g2 = studentGrades.find { it.subjectId == sub.id && it.term == 2 }
                val g3 = studentGrades.find { it.subjectId == sub.id && it.term == 3 }

                val validGrades = listOfNotNull(g1?.termAverage, g2?.termAverage, g3?.termAverage)
                val subjectFinalAvg = if (validGrades.isNotEmpty()) validGrades.average() else null
                val isPass = subjectFinalAvg != null && subjectFinalAvg >= 10.0

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = sub.name,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (subjectFinalAvg != null) {
                                val col = if (isPass) AcademicGreen else AcademicRed
                                Text(
                                    text = "${String.format(Locale.US, "%.1f", subjectFinalAvg)} Val (${if (isPass) "Aprov." else "Reprov."})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = col
                                )
                            } else {
                                Text(
                                    text = "Em Curso",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Trimestres
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "1.º Trim: ${g1?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: (g1?.qualitative ?: "-")}",
                                fontSize = 11.sp
                            )
                            Text(
                                text = "2.º Trim: ${g2?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: (g2?.qualitative ?: "-")}",
                                fontSize = 11.sp
                            )
                            Text(
                                text = "3.º Trim: ${g3?.termAverage?.let { String.format(Locale.US, "%.1f", it) } ?: (g3?.qualitative ?: "-")}",
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
