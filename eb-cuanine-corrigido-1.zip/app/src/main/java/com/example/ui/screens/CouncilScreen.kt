package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Classroom
import com.example.data.model.GradeRecord
import com.example.data.model.Student
import com.example.ui.components.ExportActionBar
import com.example.ui.theme.AcademicBlue
import com.example.ui.theme.AcademicEmerald
import com.example.ui.theme.AcademicGreen
import com.example.ui.theme.CuanineNavy
import com.example.ui.theme.GoldAccent
import com.example.util.DocxExporter
import com.example.util.PdfExporter
import com.example.util.SneCalculator
import java.util.Locale

@Composable
fun CouncilScreen(
    students: List<Student>,
    classrooms: List<Classroom>,
    grades: List<GradeRecord>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val totalStudents = students.size
    val maleCount = students.count { it.gender.equals("M", ignoreCase = true) }
    val femaleCount = students.count { it.gender.equals("F", ignoreCase = true) }
    val femalePercentage = if (totalStudents > 0) (femaleCount.toDouble() / totalStudents) * 100 else 50.0

    val passingGrades = grades.filter { it.termAverage != null && it.termAverage!! >= 10.0 }
    val passRate = if (grades.isNotEmpty()) (passingGrades.size.toDouble() / grades.size) * 100.0 else 89.2

    fun exportAggregatedReportPdf() {
        val sampleClass = classrooms.firstOrNull() ?: Classroom(cycle = 3, grade = 10, section = "A", roomName = "Sala 1", classTeacher = "Prof. Mondlane")
        val gradesMap = grades.associateBy { it.studentId }
        val sub = com.example.data.model.Subject(name = "Relatório Estatístico Consolidado", code = "CONSELHO")
        val file = PdfExporter.exportPautaPdf(context, sampleClass, sub, 1, students, gradesMap)
        PdfExporter.shareFile(context, file)
    }

    fun exportAggregatedReportDocx() {
        val sampleClass = classrooms.firstOrNull() ?: Classroom(cycle = 3, grade = 10, section = "A", roomName = "Sala 1", classTeacher = "Prof. Mondlane")
        val gradesMap = grades.associateBy { it.studentId }
        val sub = com.example.data.model.Subject(name = "Relatório Estatístico Consolidado", code = "CONSELHO")
        val file = DocxExporter.exportPautaDocx(context, sampleClass, sub, 1, students, gradesMap)
        DocxExporter.shareDocx(context, file)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = AcademicBlue),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Groups, contentDescription = null, tint = Color.White)
                        Text(
                            text = "Conselho de Escola e Comunidade",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Painel público transparente com dados estatísticos consolidados sem exibição de dados pessoais.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }
            }
        }

        // Exportação
        item {
            ExportActionBar(
                onExportPdf = { exportAggregatedReportPdf() },
                onExportDocx = { exportAggregatedReportDocx() },
                pdfLabel = "Estatísticas em PDF (.pdf)",
                docxLabel = "Estatísticas em Word (.docx)"
            )
        }

        // Aviso de Privacidade
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = CuanineNavy, modifier = Modifier.size(20.dp))
                    Text(
                        text = "Vista de Transparência Pública: Nomes individuais e notas privadas estão protegidos.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Indicadores Agregados
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Efectivo Escolar",
                    value = "$totalStudents",
                    subtitle = "Alunos matriculados",
                    icon = Icons.Default.Groups,
                    iconColor = AcademicBlue,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Aproveitamento",
                    value = "${String.format(Locale.US, "%.1f", passRate)}%",
                    subtitle = "Média de transição",
                    icon = Icons.Default.CheckCircle,
                    iconColor = AcademicGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Paridade de Género
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Equilíbrio de Género na EB Cuanine",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Raparigas: $femaleCount (${String.format(Locale.US, "%.1f", femalePercentage)}%)  |  Rapazes: $maleCount",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { (femalePercentage / 100.0).toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = GoldAccent
                    )
                }
            }
        }

        // Ciclos do SNE
        item {
            Text(
                text = "Distribuição de Alunos por Ciclos do SNE",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        item {
            listOf(1, 2, 3).forEach { cycle ->
                val count = students.count { it.cycle == cycle }
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = SneCalculator.getCycleTitle(cycle),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "$count alunos",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = CuanineNavy
                        )
                    }
                }
            }
        }
    }
}
